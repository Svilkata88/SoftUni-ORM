create view view_river_info("River Information") as
SELECT concat_ws(' '::text, 'The river', river_name, 'flows into the', outflow, 'and is', length,
                 'kilometers long.') AS "River Information"
FROM rivers "River Information"
ORDER BY river_name;

alter table view_river_info
    owner to postgres;

