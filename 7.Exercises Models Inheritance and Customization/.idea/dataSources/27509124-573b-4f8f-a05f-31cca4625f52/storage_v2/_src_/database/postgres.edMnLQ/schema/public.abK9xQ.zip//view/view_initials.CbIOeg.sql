create view view_initials(initial, last_name) as
SELECT "substring"(first_name::text, 1, 2) AS initial,
       last_name
FROM employees
ORDER BY last_name;

alter table view_initials
    owner to postgres;

