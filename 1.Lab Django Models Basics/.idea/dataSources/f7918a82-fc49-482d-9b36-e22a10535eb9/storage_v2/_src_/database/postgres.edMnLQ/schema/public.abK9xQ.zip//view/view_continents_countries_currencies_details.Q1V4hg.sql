create view view_continents_countries_currencies_details(continent_details, country_information, currencies) as
SELECT concat_ws(': '::text, TRIM(BOTH FROM con.continent_name), con.continent_code)   AS continent_details,
       concat_ws(' - '::text, ctr.country_name, ctr.capital, ctr.area_in_sq_km, 'km2') AS country_information,
       concat(cur.description, ' (', cur.currency_code, ')')                           AS currencies
FROM continents con,
     countries ctr,
     currencies cur
WHERE con.continent_code = ctr.continent_code
  AND ctr.currency_code = cur.currency_code
ORDER BY (concat_ws(' - '::text, ctr.country_name, ctr.capital, ctr.area_in_sq_km, 'km2')),
         (concat(cur.description, ' (', cur.currency_code, ')'));

alter table view_continents_countries_currencies_details
    owner to postgres;

