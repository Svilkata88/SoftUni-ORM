create view view_employee_addresses_info(full_name, department_id, address) as
SELECT concat_ws(' '::text, e.first_name, e.last_name) AS full_name,
       e.department_id,
       concat_ws(' '::text, a.number, a.street)        AS address
FROM employees e,
     addresses a
WHERE e.address_id = a.id
ORDER BY (concat_ws(' '::text, a.number, a.street));

alter table view_employee_addresses_info
    owner to postgres;

