create function fn_calculate_future_value(initial_sum integer, yearly_interest_rate numeric, number_of_years integer) returns numeric
    language plpgsql
as
$$
        DECLARE
        future_value DECIMAL;
        BEGIN
            future_value := initial_sum * POWER((1 + yearly_interest_rate), number_of_years);
            RETURN ROUND(future_value, 4);
        END;
    $$;

alter function fn_calculate_future_value(integer, numeric, integer) owner to postgres;

