create function fn_full_name(first_name character varying, last_name character varying) returns character varying
    language plpgsql
as
$$
        DECLARE
            full_name VARCHAR(50);
        BEGIN
            IF first_name IS NOT NULL and last_name IS NOT NULL THEN
                full_name := INITCAP(first_name) || ' ' || INITCAP(last_name);
            ELSEIF first_name IS NULL THEN
                full_name := INITCAP(last_name);
            ELSEIF last_name IS NULL THEN
                full_name := INITCAP(first_name);
            ELSE full_name := NULL;
            END IF;
            RETURN full_name;
        END;
    $$;

alter function fn_full_name(varchar, varchar) owner to postgres;

